from django.shortcuts import render

from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
import pandas as pd
# Create your views here.
from.models import Position, choice
from django.template import loader
from django.http import Http404
import numpy as np
import random


def index(request):
       Dataframe=pd.read_csv('BaseDeDonnées/Sex_positions.csv')
    
       if(Position.objects.all().count()):
             template = loader.get_template('Project1/index.html')
             integer=random.randint(0,Dataframe.shape[0]-1)
             context = { "imageUrl": Dataframe.loc[integer].images
                    }
             
             
             
             
             return HttpResponse(template.render(context, request))
       else:
            Position.objects.all().delete()
            for index,row in Dataframe.iterrows():
                 
                 q=Position(Position_name=row['Position Name'], Description=row['Description'],img=row['images'])
                 q.save()
                 q.choice_set.create(choice_text="0",votes=0)
                 q.choice_set.create(choice_text="1",votes=0)
                 q.choice_set.create(choice_text="2",votes=0)
                 q.choice_set.create(choice_text="3",votes=0)
                 q.choice_set.create(choice_text="4",votes=0)
                 q.choice_set.create(choice_text="5",votes=0)
            return HttpResponse("Refresh the page please")
def setupdatabase(request):
    Dataframe=pd.read_csv('BaseDeDonnées/Sex_positions.csv')  
    Dataframe=Dataframe.to_html()
    return HttpResponse(Dataframe)
def detail(request):
    template = loader.get_template('Project1/detail.html')
    d=Position.objects.order_by('id').first()
    integer=random.randint(d.id,d.id+128)
    present=Position.objects.get(id=integer)
    description=["","",""]
    description=present.Description.split('Why you should do it:')
    try:
        description[1]='Why you should do it:'+description[1]
        try:
            description.append('Make it extra special:'+description[1].split('Make it extra special:')[1])
        except Exception :
            description[2]='No extra comments for this one sorry.'
    except Exception :
         description.append('No explanation for this one')
        
          
    context={ "imageUrl": present.img,
             "positionName":present.Position_name,
             "description":description,
             "Position":present
        
        }
    
    
    return HttpResponse(template.render(context, request))
def rate(request, Position_id):
     position = get_object_or_404(Position, id=Position_id)
    
     try:
        selected_choice = position.choice_set.get(id=request.POST['choice'])
        template = loader.get_template('Project1/rate.html')
        
        context = {
        'id': Position_id,
        'position':position 
        }
     except (KeyError, choice.DoesNotExist):
         return render(request, 'Project1/rate.html', {
            'position': position,
            'error_message': "You didn't select a choice.",})
     else:
        selected_choice.votes += 1
        selected_choice.save()
     return HttpResponseRedirect(reverse('Project1:results', args=(Position_id,)))

def results(request, Position_id):
    position = get_object_or_404(Position, pk=Position_id)
    hehe=position.choice_set.all()
    somme=0
    compteur=0
    for i in hehe:
        somme=somme + int(i.choice_text)*i.votes
        compteur=compteur+i.votes
    position.avg_rating=somme/compteur
    return render(request, 'Project1/results.html', {'position': position})