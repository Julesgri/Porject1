from django.urls import path

from . import views
app_name = 'Project1'
urlpatterns = [
    path('ViewDataBase/', views.setupdatabase, name='setupdatabase'),
    path('',views.index,name='index'),
    path('detail/',views.detail,name='detail'),
    path('detail/rate/<int:Position_id>',views.rate,name='rate'),
    path('<int:Position_id>/results/', views.results, name='results'),
    
]