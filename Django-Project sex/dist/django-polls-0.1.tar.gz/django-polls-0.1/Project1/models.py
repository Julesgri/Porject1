from django.db import models
import pandas as pd

# Create your models here.
class Position(models.Model):
   
    Position_name = models.CharField(max_length=200)
    Description = models.TextField(null=True)
    img=models.TextField()
    avg_rating=models.DecimalField(default=2.5, decimal_places=2, max_digits=6)
    
    def __str__(self):
        return self.Position_name 
class choice(models.Model):
    rating = models.ForeignKey(Position, on_delete=models.CASCADE)
    choice_text = models.TextField(max_length=200)
    votes = models.IntegerField(default=0)
    def __str__(self):
	    return self.choice_text